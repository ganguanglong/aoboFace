var searchData=
[
  ['ability',['ability',['../struct_m_g___a_l_g_o_r_i_t_h_m_i_n_f_o.html#a11625766f5876f3f64b74cb209888c63',1,'MG_ALGORITHMINFO']]],
  ['age',['age',['../struct_m_g___f_a_c_e.html#a3d19097bbf869fd10db78b7e05c7c34d',1,'MG_FACE']]],
  ['auth_5ftype',['auth_type',['../struct_m_g___a_l_g_o_r_i_t_h_m_i_n_f_o.html#a0b212c9a94ccffa74a129d0429950295',1,'MG_ALGORITHMINFO']]]
];
