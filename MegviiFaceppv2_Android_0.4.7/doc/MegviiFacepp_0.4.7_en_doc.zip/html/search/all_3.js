var searchData=
[
  ['detect',['Detect',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#aa548373446fe877be6a50973e7178702',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['detection_5fmode',['detection_mode',['../struct_m_g___f_p_p___a_p_i_c_o_n_f_i_g.html#a65065072fa33c2ab05ef0c945cfc198a',1,'MG_FPP_APICONFIG']]],
  ['definition_20of_20landmark_20points',['Definition of landmark points',['../group__g__landmarks.html',1,'']]]
];
