var searchData=
[
  ['gender',['gender',['../struct_m_g___f_a_c_e.html#a806bfdfc3668813603bee43a6955df99',1,'MG_FACE']]],
  ['getalgorithminfo',['GetAlgorithmInfo',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a13fb26a5883eef5e0b9d1f4a63741740',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getapiexpiration',['GetApiExpiration',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a11165d90b7733e6ec43cbec1af262103',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getapiversion',['GetApiVersion',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a4cf47a795262d042f354d8ad821109e1',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getattribute',['GetAttribute',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a4ac56d3f28fcb18a97bbbf847d38b2d3',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getdetectconfig',['GetDetectConfig',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a1dc56210a071c3fa450ce279b36e80aa',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getfaceinfo',['GetFaceInfo',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#add105d08334445cdbe3804e14ed87fe3',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getfeaturedata',['GetFeatureData',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a98dc03bca954e19859c20929d1dd24fd',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getlandmark',['GetLandmark',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a116f91f24bb127f395deb45e9a4f4c73',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['getsdkauthtype',['GetSDKAuthType',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#ab3b9b8c4411b9a2127848548483aab9d',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]]
];
