var searchData=
[
  ['pitch',['pitch',['../struct_m_g__3_d_p_o_s_e.html#ae12f8b9ce7819c6946ab12c01792e7e6',1,'MG_3DPOSE']]],
  ['point',['point',['../struct_m_g___f_a_c_e_l_a_n_d_m_a_r_k_s.html#ab6b0978643fc40c17871d3d2ca4023b1',1,'MG_FACELANDMARKS']]],
  ['points',['points',['../struct_m_g___f_a_c_e.html#ae71833422ba21bf764407e1a7153ab31',1,'MG_FACE']]],
  ['pose',['pose',['../struct_m_g___f_a_c_e.html#ad83ae3bee9efa82f1960e142cb4eef23',1,'MG_FACE']]]
];
