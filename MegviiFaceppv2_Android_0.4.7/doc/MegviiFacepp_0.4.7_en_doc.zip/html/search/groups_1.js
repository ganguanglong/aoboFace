var searchData=
[
  ['check_20platform',['Check platform',['../group__g__platform.html',1,'']]]
];
