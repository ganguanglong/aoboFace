var indexSectionsWithContent =
{
  0: "abcdefghilmprstxy",
  1: "m",
  2: "m",
  3: "abcdefgilmprstxy",
  4: "m",
  5: "m",
  6: "m",
  7: "m",
  8: "bcd",
  9: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Modules",
  9: "Pages"
};

