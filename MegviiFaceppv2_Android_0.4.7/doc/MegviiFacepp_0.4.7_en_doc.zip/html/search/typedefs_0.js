var searchData=
[
  ['mg_5ffpp_5fapihandle',['MG_FPP_APIHANDLE',['../_m_g___facepp_8h.html#ada15f635ef909e9aca52824dd580da40',1,'MG_Facepp.h']]],
  ['mg_5ffpp_5fimagehandle',['MG_FPP_IMAGEHANDLE',['../_m_g___facepp_8h.html#a3492210206745444514ed588709ea666',1,'MG_Facepp.h']]]
];
