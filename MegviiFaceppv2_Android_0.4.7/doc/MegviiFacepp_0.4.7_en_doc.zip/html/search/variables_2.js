var searchData=
[
  ['confidence',['confidence',['../struct_m_g___f_a_c_e.html#ab61f801c8d14f8686654facb639bb763',1,'MG_FACE']]],
  ['createapihandle',['CreateApiHandle',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#ae5b4677b247cb0c7a882b2542491e0d9',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]],
  ['createimagehandle',['CreateImageHandle',['../struct_m_g___f_a_c_e_p_p___a_p_i___f_u_n_c_t_i_o_n_s___t_y_p_e.html#a77438b4530db1a84ce47ef285fd4129f',1,'MG_FACEPP_API_FUNCTIONS_TYPE']]]
];
